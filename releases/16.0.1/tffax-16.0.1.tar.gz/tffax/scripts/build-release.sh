#!/usr/bin/env bash
set -euo pipefail
VERSION="${1:-16.0.1}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${2:-$ROOT/dist}"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
mkdir -p "$OUT" "$WORK/tffax"
rsync -a --exclude '.git' --exclude 'dist' "$ROOT/" "$WORK/tffax/"
find "$WORK/tffax" -type f -name '*.php' -print0 | xargs -0 -n1 php -l >/dev/null
( cd "$WORK" && tar -czf "$OUT/tffax-${VERSION}.tar.gz" tffax )
( cd "$WORK" && zip -qr "$OUT/tffax-${VERSION}-src.zip" tffax )
( cd "$OUT" && sha256sum "tffax-${VERSION}.tar.gz" "tffax-${VERSION}-src.zip" > "tffax-${VERSION}-SHA256SUMS.txt" )
printf 'Built release artifacts in %s\n' "$OUT"
