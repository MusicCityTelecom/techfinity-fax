# Changelog

## 16.0.1 - 2026-08-21

First public TechFinity Fax release.

- Reworked branding for a generic open-source distribution.
- Added FreePBX 16/17 support metadata.
- Added User Management-based portal authentication and user mapping.
- Added `/fax/` public portal installer.
- Moved module-owned spool to `/var/spool/asterisk/tffax`.
- Added DID normalization for common NANP formats.
- Added configurable timezone with `America/Chicago` default.
- Added administrator-editable email notification templates.
- Added default-style administration navigation and forms.
- Added installation, security, contribution and release-build documentation.
