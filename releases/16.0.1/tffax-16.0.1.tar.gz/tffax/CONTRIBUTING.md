# Contributing

Contributions are welcome. Keep changes scoped to TechFinity Fax, preserve compatibility with supported FreePBX releases, and do not include proprietary third-party code or customer data.

Before submitting a pull request:

```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
```

Describe installation/upgrade impact, database schema impact, dialplan changes and testing performed.
