<?php
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
$mod = FreePBX::Tffax();
function tfh($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
if (empty($_SESSION['tffax_csrf'])) $_SESSION['tffax_csrf']=bin2hex(random_bytes(24));
if (isset($_GET['logout'])) { unset($_SESSION['tffax_portal_user']); header('Location: ./'); exit; }
if (isset($_GET['file'],$_GET['id']) && !empty($_SESSION['tffax_portal_user'])) { $mod->serveJobFile((int)$_GET['id'],$_GET['file']==='download'); exit; }
$error='';
if (($_SERVER['REQUEST_METHOD']??'')==='POST' && isset($_POST['login'])) {
  $u=$mod->authenticateUserman($_POST['username']??'',$_POST['password']??'');
  if ($u) { $_SESSION['tffax_portal_user']=$u; header('Location: ./'); exit; }
  $error='Invalid credentials or fax access has not been assigned to this account.';
}
$user=$_SESSION['tffax_portal_user']??null;
if ($user && ($_SERVER['REQUEST_METHOD']??'')==='POST' && !isset($_POST['login'])) {
  if (!hash_equals($_SESSION['tffax_csrf'],(string)($_POST['csrf']??''))) $error='Invalid form token.';
  else {
    try {
      if (isset($_POST['send_fax']) && !empty($user['can_send'])) { $_POST['tffax_action']='send_fax'; $mod->processPost($_POST,$_FILES); header('Location: ./'); exit; }
    } catch (Throwable $e) { $error=$e->getMessage(); }
  }
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TechFinity Fax</title>
<style>body{font-family:Arial,sans-serif;background:#f5f6f7;margin:0;color:#222}.wrap{max-width:1050px;margin:32px auto;padding:0 16px}.card{background:white;border:1px solid #ddd;border-radius:6px;padding:22px;margin-bottom:18px}.top{display:flex;justify-content:space-between;align-items:center}input,select,textarea{box-sizing:border-box;width:100%;padding:10px;border:1px solid #bbb;border-radius:4px;margin:5px 0 12px}button,.btn{display:inline-block;background:#337ab7;color:white;border:0;border-radius:4px;padding:10px 15px;text-decoration:none;cursor:pointer}.btn2{background:#666}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:9px;border-bottom:1px solid #ddd}.err{background:#f2dede;border:1px solid #ebccd1;color:#a94442;padding:10px;border-radius:4px;margin-bottom:12px}.ok{background:#dff0d8;padding:10px;border-radius:4px;margin-bottom:12px}@media(max-width:700px){table{font-size:12px}.top{align-items:flex-start;gap:12px}}</style></head><body><div class="wrap">
<?php if(!$user): ?><div class="card" style="max-width:430px;margin:70px auto"><h1>TechFinity Fax</h1><p>Sign in with your User Management account.</p><?php if($error):?><div class="err"><?=tfh($error)?></div><?php endif;?><form method="post"><input type="hidden" name="login" value="1"><label>Username</label><input name="username" required autofocus autocomplete="username"><label>Password</label><input type="password" name="password" required autocomplete="current-password"><button>Sign In</button></form></div>
<?php else: ?><div class="card top"><div><h1 style="margin:0">TechFinity Fax</h1><small><?=tfh($user['user_name'])?></small></div><a class="btn btn2" href="?logout=1">Sign Out</a></div><?php if($error):?><div class="err"><?=tfh($error)?></div><?php endif;?>
<?php if(!empty($user['can_send'])): $ids=$mod->getIdentities(true); $covers=$mod->getCoverPages(true); ?><div class="card"><h2>Send Fax</h2><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=tfh($_SESSION['tffax_csrf'])?>"><input type="hidden" name="send_fax" value="1"><label>Fax Number</label><input name="destination_number" required><label>Fax Identity</label><select name="identity_id" required><?php foreach($ids as $i):?><option value="<?=$i['id']?>"><?=tfh($i['name'])?></option><?php endforeach;?></select><label>Recipient Name</label><input name="recipient_name"><label>Subject</label><input name="subject"><label>Cover Page</label><select name="coverpage_id"><option value="0">None</option><?php foreach($covers as $c):?><option value="<?=$c['id']?>"><?=tfh($c['name'])?></option><?php endforeach;?></select><label>Document (PDF, TIFF, JPG, PNG)</label><input type="file" name="faxfile" required><button>Send Fax</button></form></div><?php endif;?>
<div class="card"><h2>Fax History</h2><?php $jobs=$mod->getJobs(100); if(empty($user['can_view_all']))$jobs=array_values(array_filter($jobs,function($j)use($user){return strcasecmp((string)$j['user_name'],(string)$user['user_name'])===0;}));?><table><thead><tr><th>Date</th><th>Direction</th><th>From</th><th>To</th><th>Status</th><th>Pages</th><th></th></tr></thead><tbody><?php foreach($jobs as $j):?><tr><td><?=tfh($mod->formatLocalTime($j['created_at']))?></td><td><?=tfh($j['direction'])?></td><td><?=tfh($j['source_number'])?></td><td><?=tfh($j['destination_number'])?></td><td><?=tfh($j['status'])?></td><td><?=tfh($j['pages'])?></td><td><?php if(!empty($j['pdf_path'])||!empty($j['document_path'])):?><a href="?id=<?=$j['id']?>&file=view">View</a><?php endif;?></td></tr><?php endforeach;?></tbody></table></div>
<?php endif; ?></div></body></html>
